---
description: Google Maps'te mekan araştır ve detaylı liste çıkar
argument-hint: <ne arıyorsun, nerede>
---

maps-arastirma skill'ini kullanarak şunu araştır: $ARGUMENTS

Sonuçları puana göre sıralı tablo olarak ver ve sonda kısa bir değerlendirme ekle.
