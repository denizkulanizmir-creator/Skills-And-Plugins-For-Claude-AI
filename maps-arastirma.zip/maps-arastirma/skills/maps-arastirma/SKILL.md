---
name: maps-arastirma
description: Google Maps verisiyle mekan, işletme ve bölge araştırması yapar. Kullanıcı bir semtteki kafeleri, rakipleri, müşteri adaylarını, restoranları ya da herhangi bir işletme türünü araştırmak, karşılaştırmak veya listelemek istediğinde, "yakınımdaki", "şu bölgedeki", "haritada bak" gibi ifadeler kullandığında bu skill'i mutlaka kullan, açıkça "Google Maps" dememiş olsa bile.
---

# Maps Araştırma

Google Maps bağlantısını (google-maps MCP) kullanarak mekan araştırması yap. Siteyi kazımaya çalışma, sadece bağlayıcının araçlarını kullan.

## Akış

1. İsteği netleştir: ne arıyoruz, hangi bölgede, ne amaçla (rakip analizi, müşteri adayı, gezi, vs.). Amaç belli değilse tek bir kısa soru sor.
2. Önce geniş bir arama yap, sonra en alakalı 5-10 sonuç için ayrıntı çek.
3. Aramayı gerekirse farklı açılardan tekrarla (örneğin "kahveci" ve "specialty coffee"), tekrar eden mekanları birleştir.

## Her mekan için çekilecek alanlar

- İsim ve tür
- Adres ve semt
- Telefon ve web sitesi
- Puan ve yorum sayısı
- Çalışma saatleri
- Fiyat seviyesi (varsa)
- Konum (enlem, boylam)
- Yorumlardan öne çıkan 1-2 tekrar eden tema (kısaca, kendi cümlelerinle)

Bir alan yoksa uydurma, "bilgi yok" yaz.

## Çıktı

- Önce 2-3 cümlelik genel bir özet: bölgede ne var, kim öne çıkıyor.
- Sonra mekanları puan ve yorum sayısına göre sıralı bir tabloda ver.
- Amaca göre kısa bir yorum ekle (rakip analizinde boşluklar, müşteri adayında en uygun hedefler, gezide rota sırası).
- Kullanıcı isterse tabloyu CSV ya da xlsx dosyasına dönüştür.

## Dikkat

- Puanlar az yorumla yanıltıcıdır. 20'den az yorumu olan mekanın puanını belirt ama öne çıkarma.
- Kapalı ya da taşınmış görünen yerleri işaretle.
- Kişisel veri toplama, sadece işletmelerin herkese açık bilgilerini kullan.
