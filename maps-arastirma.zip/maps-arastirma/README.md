# maps-arastirma

Google Maps ile mekan araştırması yapan Claude eklentisi.

## Kurulum
1. Google Cloud'da bir proje aç, Places API'yi etkinleştir, API anahtarı al.
2. Anahtarı ortam değişkeni olarak tanımla: GOOGLE_MAPS_API_KEY
3. Klasörü zip'leyip eklenti olarak yükle.

## Kullanım
/mekan Karşıyaka'da specialty kahveciler
